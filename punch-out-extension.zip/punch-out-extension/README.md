# Punch-Out Calculator

Chrome extension (MV3), tuned for Samsung's MySmartTime portal
(`mdmapi.swap-siel.com`). Clicking the toolbar icon injects a floating,
draggable, minimizable panel directly onto the current page (drag by the
header; `–` minimizes to just the header bar; `×` removes it; click the icon
again to toggle it back). There's no separate popup window — the panel lives
on the page itself, so it can scan the page in place and stays open while you
work.

## Inputs

- **First Punch In** today — base point for the 4:30 floor and 9hr/12hr slab
  ceilings below. Each of those gets shifted *later* by however much
  Aggregated Outside Time you enter, since those thresholds are about **net
  hours worked**, not raw wall-clock span since arrival — break time doesn't
  count against them.
- **Office Out (last recorded)** — leave blank if no break has happened yet
  today. Short Considered only gets recalculated by the portal AT a
  punch-out — it never ticks live while you're sitting there working — so
  Safe Output Time always anchors to the instant Short Considered was
  actually computed (Office Out if it exists, else First Punch In), **never**
  to "now". There's no "currently punched in" toggle — whether you're
  physically at your desk doesn't tell us whether Short Considered has
  refreshed, so it can't be the deciding signal.
- **Short Considered** — read fresh from the portal every time you check, and
  trusted directly as net work still owed (before any mandatory break — see
  below).
- **Aggregated time outside office today** — one manual total across every
  break today, however many separate times you went out.

## Outputs (`calc.js#computePunchOutPlan`)

1. **Safe output time** — `anchor + remainingRequired`, clamped to the 4:30
   floor and 12-hour cap below. `anchor` = Office Out (last recorded) if any
   punch-out has happened today, else First Punch In — never "now".
   `remainingRequired` = Short Considered, **plus `max(30min, Aggregated Outside Time)`**
   once Short Considered exceeds 4:30 (a half-day worth of work carries no
   break requirement; anything longer does). 30 min is just the floor — if
   you've actually been outside longer than that today, the extra time has
   to be made up too.
2. **Save time out Time** — the latest moment in the current 9-hour "slab" of
   *net worked time* before you cross into overtime and the extra-credit
   counter resets. Slab 1 ceiling = firstPunchIn + 8:59:59 + outside time.
   Once net worked time crosses 9:00:00, a fresh slab 2 window opens with
   ceiling = firstPunchIn + 11:59:59 + outside time.
3. **12-hour hard cap** — shown only once net worked time crosses 9:00:00.
   firstPunchIn + 12:00:00 + outside time, exact, no buffer.
4. **4:30 floor** — firstPunchIn + 4:30 + outside time, the earliest you can
   ever leave regardless of debt.

## Load it

1. Open `chrome://extensions`
2. Enable "Developer mode" (top right)
3. "Load unpacked" → select this folder
4. Click the extension icon on the portal page to open the panel
5. After editing any file, hit the refresh icon on the extension's card, then
   reload the portal tab (or click the icon twice) to pick up changes

## Scanning the page

"Scan this page" runs `scanPageForPunchData` (in `content.js`) directly
against the page the panel is on and pairs each value element with its
next-sibling label element (on MySmartTime: `<h3>value</h3><p>label</p>`). It
auto-fills First Punch In and Short Considered. Aggregated Outside Time stays
manual — there's no portal field for it yet.

**Porting to a different site** (e.g. a VDI-hosted portal with the same
fields): edit only the `CONFIG` block inside `scanPageForPunchData` in
`content.js` — `valueTag`/`labelTag` if the value/label element types differ,
`labelAliases` if the wording differs. The pairing logic below it is generic
and shouldn't need to change unless the other site puts the label *before*
the value.

## Current state

`calc.js` has no browser dependencies — run node one-liners against it
directly for quick checks (`node -e "require('./calc.js')..."`), no build
step needed.
