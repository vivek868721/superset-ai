// Pure calculation logic — no DOM, no browser APIs. Usable from content.js and from tests.
// Wrapped in an IIFE so re-injecting this file into the same page (e.g. clicking the
// toolbar icon again) never throws "already declared" for top-level consts.
(function () {
  const MIN = 60;
  const HOUR = 3600;

  const SLAB1_CEILING_SEC = 8 * HOUR + 59 * MIN + 59; // net worked must stay under 9:00:00
  const SLAB2_CEILING_SEC = 11 * HOUR + 59 * MIN + 59; // net worked must stay under 12:00:00
  const HARD_CAP_SEC = 12 * HOUR; // absolute must-be-out-by (net worked), no buffer
  const MIN_DAILY_SEC = 4 * HOUR + 30 * MIN; // absolute floor on net worked time
  const MAX_DAILY_SEC = HARD_CAP_SEC; // absolute cap on net worked time
  const HALF_DAY_THRESHOLD_SEC = 4 * HOUR + 30 * MIN; // above this, a mandatory break is owed
  const MANDATORY_BREAK_SEC = 30 * MIN; // lunch break owed once the day is more than half-day length
  const LONG_BREAK_SEC = HOUR; // 1hr+ outside means the basic day already runs long; hide Save Time Out Time
  const SINGLE_DAY_SEC = 8 * HOUR; // Short Considered beyond this looks like stacked pending days

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  // "HH:MM" or "HH:MM:SS" -> total seconds. Leading "-" is kept as a sign.
  function parseDuration(str) {
    const trimmed = String(str).trim();
    const negative = trimmed.startsWith('-');
    const parts = trimmed.replace('-', '').split(':').map(Number);
    if (parts.some((n) => Number.isNaN(n))) throw new Error(`Invalid duration: ${str}`);
    const [h = 0, m = 0, s = 0] = parts;
    const total = h * HOUR + m * MIN + s;
    return negative ? -total : total;
  }

  function formatDuration(totalSeconds) {
    const sign = totalSeconds < 0 ? '-' : '';
    const abs = Math.abs(Math.round(totalSeconds));
    const h = Math.floor(abs / HOUR);
    const m = Math.floor((abs % HOUR) / MIN);
    const s = abs % MIN;
    return `${sign}${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function formatClock(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  /**
   * @param {Object} input
   * @param {Date} input.firstPunchIn - first punch-in of the day. Base point for the
   *   4:30 floor and 9hr/12hr slab ceilings — each gets shifted later by
   *   aggregatedOutsideSec, since those thresholds are about NET hours worked, not raw
   *   wall-clock span since arrival.
   * @param {Date|null} input.officeOut - the portal's last recorded punch-out today, if any.
   *   Short Considered only gets recalculated by the portal AT a punch-out — it never ticks
   *   live while you're sitting there working, so the anchor for Safe Output Time is always
   *   "the instant Short Considered was actually computed", not "now". That's officeOut if
   *   at least one punch-out has happened today, else firstPunchIn (before any punch-out,
   *   Short Considered reflects the start of the day).
   * @param {number} input.shortConsideredSec - "Short Considered" exactly as currently shown
   *   on the portal. Trusted directly — re-read it fresh every time you check. Represents net
   *   work still owed, before any mandatory break.
   * @param {number} input.aggregatedOutsideSec - total time spent outside the office today,
   *   summed across every break (however many times he went out) — one manual number.
   * @param {Date} input.now - current time
   */
  function computePunchOutPlan({ firstPunchIn, officeOut, shortConsideredSec, aggregatedOutsideSec, now }) {
    const netRequiredSec = Math.max(0, shortConsideredSec);
    // A half-day (<=4:30 net work) carries no mandatory break. Anything longer owes at least a
    // 30-min lunch break on top of the net work itself — or however much longer he's actually
    // been outside today, if that's more than 30 min (that extra time already ate into the
    // work window and has to be made up too).
    const breakOwedSec = Math.max(MANDATORY_BREAK_SEC, aggregatedOutsideSec);
    const remainingRequiredSec =
      netRequiredSec > HALF_DAY_THRESHOLD_SEC ? netRequiredSec + breakOwedSec : netRequiredSec;

    const warnings = [];

    if (netRequiredSec > SINGLE_DAY_SEC) {
      const extraDays = Math.floor(netRequiredSec / SINGLE_DAY_SEC);
      warnings.push(
        `Short Considered is more than a single day's worth (8h) — looks like ~${extraDays} ` +
          'pending/unapproved leave or WFH day(s) stacked in. Get those approved, or use the ' +
          '"-8h" button to knock a day off once one is.'
      );
    }

    const anchor = officeOut || firstPunchIn;

    // Anchored the same way as Safe Output Time below, and for the same reason: gross elapsed
    // must freeze at the last confirmed instant (officeOut), not keep ticking with real "now" —
    // otherwise checking late in the evening would silently look like he'd kept working for
    // hours he was actually away, flipping into slab 2 and masking real staleness.
    const netWorkedSoFarSec = (anchor - firstPunchIn) / 1000 - aggregatedOutsideSec;
    const pastNineHours = netWorkedSoFarSec >= 9 * HOUR;

    const slabCeilingSec = pastNineHours ? SLAB2_CEILING_SEC : SLAB1_CEILING_SEC;
    const saveTimeOutTime = new Date(
      firstPunchIn.getTime() + (slabCeilingSec + aggregatedOutsideSec) * 1000
    );

    let safeOutputTime = new Date(anchor.getTime() + remainingRequiredSec * 1000);
    // Being past Safe Output Time (the minimum) is completely normal if he's still working —
    // that's just banking extra credit, exactly what Save Time Out Time is for. Only flag
    // staleness once real time has passed THAT later ceiling; before it, there's nothing wrong.
    if (saveTimeOutTime < now) {
      warnings.push(
        "You've passed today's Save Time Out ceiling — any extra credit has reset, and Short " +
          "Considered on the portal may no longer reflect current progress. Recheck it for an " +
          'updated figure.'
      );
    }
    const floorTime = new Date(firstPunchIn.getTime() + (MIN_DAILY_SEC + aggregatedOutsideSec) * 1000);
    const capTime = new Date(firstPunchIn.getTime() + (MAX_DAILY_SEC + aggregatedOutsideSec) * 1000);

    if (safeOutputTime < floorTime) {
      safeOutputTime = floorTime; // must stay at least 4:30 NET worked, even if debt is already cleared
    }
    if (safeOutputTime > capTime) {
      warnings.push(
        "Can't fully clear today's Short Considered debt within the 12-hour cap. " +
          'Safe output time capped at the 12-hour mark — remaining debt carries over.'
      );
      safeOutputTime = capTime;
    }

    const result = {
      remainingRequiredSec,
      safeOutputTime,
      saveTimeOutTime,
      // Once the break itself is 1hr+, the basic (non-overtime) day already runs long enough
      // that "stay a bit more to bank extra credit" isn't meaningful advice — hide it.
      showSaveTimeOutTime: aggregatedOutsideSec < LONG_BREAK_SEC,
      floorTime, // earliest he can ever leave, regardless of debt — firstPunchIn + 4:30 + outside time
      slab: pastNineHours ? 2 : 1,
      warnings,
    };

    if (pastNineHours) {
      result.hardCapTime = new Date(firstPunchIn.getTime() + (HARD_CAP_SEC + aggregatedOutsideSec) * 1000);
    }

    return result;
  }

  const exported = {
    clamp,
    parseDuration,
    formatDuration,
    formatClock,
    computePunchOutPlan,
    SLAB1_CEILING_SEC,
    SLAB2_CEILING_SEC,
    HARD_CAP_SEC,
    MIN_DAILY_SEC,
    MAX_DAILY_SEC,
    HALF_DAY_THRESHOLD_SEC,
    MANDATORY_BREAK_SEC,
    LONG_BREAK_SEC,
    SINGLE_DAY_SEC,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = exported; // Node/CommonJS, for quick node -e checks
  } else if (!window.PunchOutCalc) {
    window.PunchOutCalc = exported; // guard: harmless if this file is injected twice
  }
})();
