// No default_popup in manifest.json, so this fires on every toolbar-icon
// click. Re-injecting is safe — calc.js and content.js both guard against
// being run twice on the same page (content.js just toggles the existing
// panel's visibility instead of rebuilding it).
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['calc.js', 'content.js'] });
  } catch (err) {
    console.error('[punch-out-extension] failed to open panel:', err);
  }
});
