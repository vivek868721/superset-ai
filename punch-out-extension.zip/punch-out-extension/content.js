// Injected on toolbar-icon click (see background.js). Wrapped in an IIFE so
// clicking the icon again — which re-injects this file — just toggles the
// existing panel instead of throwing on redeclared top-level consts.
(function () {
  const existing = document.getElementById('poe-panel');
  if (existing) {
    existing.classList.toggle('poe-hidden');
    return;
  }

  const { computePunchOutPlan, formatClock, formatDuration, parseDuration } = window.PunchOutCalc;

  function toTodayDate(timeStr) {
    if (!timeStr) return null;
    const [h, m, s = 0] = timeStr.split(':').map(Number);
    const d = new Date();
    d.setHours(h, m, s, 0);
    return d;
  }

  // ==========================================================================
  // Build the panel
  // ==========================================================================
  const panel = document.createElement('div');
  panel.id = 'poe-panel';
  panel.innerHTML = `
    <div class="poe-header">
      <h1>⏱ Punch-Out Calculator</h1>
      <div class="poe-header-btns">
        <button id="poe-minBtn" title="Minimize">&#8211;</button>
        <button id="poe-closeBtn" title="Close">&times;</button>
      </div>
    </div>
    <div class="poe-body">
      <button id="poe-scanBtn" class="poe-action poe-secondary">&#128269; Scan this page</button>

      <div class="poe-field">
        <label for="poe-firstPunchIn">First Punch In (today)</label>
        <input id="poe-firstPunchIn" type="time" step="1" />
        <small>On WFH days this is VDI Session In — same field, same rules.</small>
      </div>

      <div class="poe-field">
        <label for="poe-officeOut">Office Out (last recorded)</label>
        <input id="poe-officeOut" type="time" step="1" />
        <small>On WFH days this is VDI Session Out. If Scan doesn't fill this, enter it manually.</small>
      </div>

      <div class="poe-field">
        <label for="poe-shortConsidered">Short Considered (right now)</label>
        <div class="poe-inputRow">
          <input id="poe-shortConsidered" type="text" placeholder="e.g. 3:42 (HH:MM)" value="0:00" />
          <button id="poe-minus8Btn" type="button" title="Subtract 8h — use once a pending leave/WFH day gets approved">-8h</button>
        </div>
        <small>Can jump by multiples of ~8hrs if a leave or WFH request is still pending/unapproved — enter it manually in that case.</small>
      </div>

      <div class="poe-field">
        <label for="poe-aggregatedOutside">Aggregated time outside office today</label>
        <input id="poe-aggregatedOutside" type="text" placeholder="e.g. 0:25 (HH:MM)" value="0:00" />
      </div>

      <button id="poe-calcBtn" class="poe-action poe-primary">Calculate</button>

      <div id="poe-result"></div>
    </div>
  `;
  document.body.appendChild(panel);

  const header = panel.querySelector('.poe-header');
  const resultEl = panel.querySelector('#poe-result');

  // ==========================================================================
  // Drag
  // ==========================================================================
  let dragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;

  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('button')) return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const x = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, e.clientX - dragOffsetX));
    const y = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - dragOffsetY));
    panel.style.left = `${x}px`;
    panel.style.top = `${y}px`;
    panel.style.right = 'auto';
  });
  document.addEventListener('mouseup', () => {
    dragging = false;
  });

  // ==========================================================================
  // Minimize / close
  // ==========================================================================
  panel.querySelector('#poe-minBtn').addEventListener('click', () => {
    panel.classList.toggle('poe-minimized');
  });
  panel.querySelector('#poe-closeBtn').addEventListener('click', () => {
    panel.remove();
  });

  // ==========================================================================
  // Quick fix: once a pending leave/WFH day gets approved, knock 8h off
  // Short Considered without retyping the whole value (see PunchOutCalc.SINGLE_DAY_SEC).
  // ==========================================================================
  panel.querySelector('#poe-minus8Btn').addEventListener('click', () => {
    const input = panel.querySelector('#poe-shortConsidered');
    try {
      const remaining = Math.max(0, parseDuration(input.value || '0:00') - window.PunchOutCalc.SINGLE_DAY_SEC);
      input.value = formatDuration(remaining);
    } catch {
      // leave the field as-is if it wasn't a valid duration yet
    }
  });

  // ==========================================================================
  // Calculate
  // ==========================================================================
  panel.querySelector('#poe-calcBtn').addEventListener('click', () => {
    try {
      const firstPunchIn = toTodayDate(panel.querySelector('#poe-firstPunchIn').value);
      if (!firstPunchIn) throw new Error('Enter the first punch-in time.');

      const shortConsideredSec = parseDuration(panel.querySelector('#poe-shortConsidered').value || '0:00');
      const aggregatedOutsideSec = parseDuration(panel.querySelector('#poe-aggregatedOutside').value || '0:00');
      const officeOut = toTodayDate(panel.querySelector('#poe-officeOut').value);
      const now = new Date();

      const plan = computePunchOutPlan({ firstPunchIn, officeOut, shortConsideredSec, aggregatedOutsideSec, now });

      resultEl.className = plan.warnings.length ? 'poe-warn' : 'poe-ok';
      resultEl.style.display = 'block';

      const row = (label, value, caption) => `
        <div class="poe-row">
          <div class="poe-row-label">${label}</div>
          <div class="poe-row-value">${value}</div>
          <div class="poe-row-caption">${caption}</div>
        </div>
      `;

      resultEl.innerHTML = `
        ${row('Safe punch out time', formatClock(plan.safeOutputTime), 'The earliest you can safely punch out today')}
        ${
          plan.showSaveTimeOutTime
            ? row(
                `Credit your time <span class="poe-slab">slab ${plan.slab}</span>`,
                formatClock(plan.saveTimeOutTime),
                'After this, all credit for the day resets'
              )
            : ''
        }
        ${
          plan.hardCapTime
            ? row('12-hour hard cap', formatClock(plan.hardCapTime), 'Absolute must-leave-by time')
            : ''
        }
        ${row(
          '4:30 floor (earliest ever)',
          formatClock(plan.floorTime),
          "Can't leave before this, even on a half day"
        )}
        ${row('Remaining required', formatDuration(plan.remainingRequiredSec), 'What you still owe today')}
        ${plan.warnings.map((w) => `<div class="poe-warning">⚠ ${w}</div>`).join('')}
      `;
      resultEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (err) {
      resultEl.className = 'poe-warn';
      resultEl.style.display = 'block';
      resultEl.textContent = `Error: ${err.message}`;
      resultEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });

  // ==========================================================================
  // Scan (runs directly against this page — no cross-tab messaging needed
  // since the panel is now injected straight into the portal page itself)
  //
  // What "Scan this page" actually fetches, and where each value goes:
  //   found.officeIn         -> #poe-firstPunchIn ("First Punch In")
  //   found.officeOut        -> #poe-officeOut ("Office Out (last recorded)")
  //   found.shortConsidered  -> #poe-shortConsidered ("Short Considered")
  // scanPageForPunchData() (below) also detects found.consideredHours,
  // found.breakTime, found.lossOfPay, found.targetHours on the MySmartTime
  // portal, but none of those are wired to any input here — computePunchOutPlan
  // (in calc.js) doesn't use them, so they're scanned and discarded.
  // #poe-aggregatedOutside ("Aggregated time outside office today") is NEVER
  // filled by Scan — there's no portal field for it, it's manual-only.
  // ==========================================================================
  panel.querySelector('#poe-scanBtn').addEventListener('click', () => {
    const found = scanPageForPunchData();
    console.log('[punch-out-extension] scanned fields:', found);
    if (found.officeIn) panel.querySelector('#poe-firstPunchIn').value = found.officeIn;
    if (found.officeOut) panel.querySelector('#poe-officeOut').value = found.officeOut;
    if (found.shortConsidered) panel.querySelector('#poe-shortConsidered').value = found.shortConsidered;
  });

  // ============================================================================
  // PORTING TO A DIFFERENT SITE (e.g. the VDI portal): edit CONFIG below only.
  // Everything past CONFIG is generic pairing/matching logic and shouldn't need
  // to change unless the other site's markup shape is fundamentally different
  // (e.g. label appears BEFORE the value instead of after).
  // ============================================================================
  function scanPageForPunchData() {
    const CONFIG = {
      // SITE-SPECIFIC: the element holding the VALUE (e.g. "10:51:25", "3:42").
      // On MySmartTime this is always an <h3>.
      valueTag: 'H3',
      // SITE-SPECIFIC: the element holding the LABEL, expected to be the value
      // element's very next sibling (e.g. "Office In", "Short Considered
      // Hours"). On MySmartTime this is always a <p>.
      labelTag: 'P',
      // SITE-SPECIFIC: raw-label -> field-key. Longer/more specific phrases
      // must come before shorter ones they contain (e.g. "short considered"
      // before "considered"). Add rows here if the other site phrases a
      // label differently (e.g. "In Time" instead of "Office In").
      labelAliases: [
        // WFH days show "VDI Session In/Out" instead of "Office In/Out" — same rules apply,
        // this just recognizes the WFH naming so Scan still works on those days.
        { key: 'officeIn', matches: ['office in', 'punch in', 'vdi session in'] },
        { key: 'officeOut', matches: ['office out', 'punch out', 'vdi session out'] },
        { key: 'shortConsidered', matches: ['short considered'] },
        { key: 'consideredHours', matches: ['considered hours'] },
        { key: 'breakTime', matches: ['break time'] },
        { key: 'lossOfPay', matches: ['loss of pay'] },
        { key: 'targetHours', matches: ['target'] },
      ],
    };

    function normalizeLabel(el) {
      return el.innerHTML
        .replace(/<br\s*\/?>/gi, ' ') // e.g. "Considered<br>Hours" -> "Considered Hours"
        .replace(/<[^>]+>/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
    }

    const found = {};
    document.querySelectorAll(CONFIG.valueTag).forEach((valueEl) => {
      if (panel.contains(valueEl)) return; // never scan our own panel
      const labelEl = valueEl.nextElementSibling;
      if (!labelEl || labelEl.tagName !== CONFIG.labelTag) return;

      const labelText = normalizeLabel(labelEl);
      const alias = CONFIG.labelAliases.find((a) => a.matches.some((m) => labelText.includes(m)));
      if (alias) found[alias.key] = valueEl.textContent.trim();
    });

    return found;
  }
})();
